// This is an example of a global variable
const globalVar = {
  mail: "umit2002colak@gmail.com",
  username: "umitcolakk",

};

export default globalVar;


